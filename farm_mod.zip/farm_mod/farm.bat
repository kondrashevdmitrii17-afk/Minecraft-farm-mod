@echo off
python Farm.py
pause